#!/usr/bin/python3

import math
# from turtle import position
import rospy
import numpy as np
import tf
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import matplotlib.pyplot as plt

class PIDController():


    def __init__(self):

        rospy.loginfo("Start making")

        self.cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=5)
        
        rospy.init_node('square', anonymous=False)
        def shutdown():
            rospy.loginfo("Stopping the robot...")
            self.cmd_vel.publish(Twist())
            plt.plot(list(range(len(self.errs))), self.errs, label='errs')
            plt.axhline(y=0,color='R')
            plt.draw()
            plt.legend(loc="upper left", frameon=False)
            plt.savefig(f"errs_{self.k_p}_{self.k_d}_{self.k_i}.png")
            plt.show()

            rospy.sleep(1)
        rospy.on_shutdown(shutdown)

        self.mode = rospy.get_param("/square/mode")
        mode = self.mode

        modes = {}
        modes["square"] = [0, 0.8, 10, 0.4, 1]
        modes["maze"] = [0, 1.5, 20, 0.2, 0.5]
        modes["path_to_goal"] = [0, 1.5, 15, 0.3, 0.5]

        self.k_i = modes[mode][0]
        self.k_p = modes[mode][1]
        self.k_d = modes[mode][2]
        self.v = modes[mode][3]
        self.D = modes[mode][4]

        self.goalx = 3
        self.goaly = -1

        self.dt = 0.005
        rate = 1/self.dt
        
        self.r = rospy.Rate(rate)
        self.errs = []
        rospy.loginfo("Finished")

    def distance_to_goal(self, odometry):
        position = odometry.pose.pose.position
        return math.sqrt((self.goalx - position.x)**2 + (self.goaly - position.y)**2)
    
    def current_heading(self, msg: Odometry, mode):
        if mode == "current":
            orientation = msg.pose.pose.orientation
            roll, pitch, yaw = tf.transformations.euler_from_quaternion((
                orientation.x ,orientation.y ,orientation.z ,orientation.w
            )) 
            return float("{:.2f}".format(yaw))
        else:
            position = msg.pose.pose.position
            return float("{:.2f}".format(np.arctan2((self.goaly - position.y), (self.goalx - position.x))))

    def angle_difference(self, odometry):
        goal_heading = self.current_heading(odometry, "goal")
        current_heading = self.current_heading(odometry, "current")

        if current_heading > 0:
            sign = -1 if (current_heading - pi < goal_heading < current_heading) else +1
        else:
            sign = +1 if (current_heading + pi > goal_heading > current_heading) else -1
        return sign * (pi - abs(abs(current_heading - goal_heading) - pi))

    def window_interval(self, diff, r):
        angle = int(diff * 180 / pi)
        left_w = angle - r 
        if left_w < -180:
            left_w += 360
        right_w = angle + r
        if right_w > 180:
            right_w -= 360
        return left_w, right_w

    def is_window_clear(self, laser_scan, odometry):
        laser_range = laser_scan.ranges
        distance = self.distance_to_goal(odometry)

        diff = self.angle_difference(odometry)
        left_i, right_i = self.window_interval(diff, 20)

        if left_i * right_i > 0:
            return True if min(laser_range[left_i:right_i]) > distance else False
        else:
            return True if min(laser_range[left_i:] + laser_range[:right_i]) > distance else False

    def follow_wall(self):
        
        sum_i_theta = 0
        previous_error = 0
        
        move = Twist()
        move.angular.z = 0
        move.linear.x = self.v

        while not rospy.is_shutdown():
            self.cmd_vel.publish(move)

            laser_scan = rospy.wait_for_message("/scan", LaserScan)
            odometry = rospy.wait_for_message("/odom", Odometry)

            if self.mode == "path_to_goal" and self.distance_to_goal(odometry) < 0.2:
                rospy.signal_shutdown("goal is reached")

            if self.mode == "path_to_goal":
                reachable = self.is_window_clear(laser_scan, odometry)
            else:
                reachable = False

            if reachable:
                stop = Twist()
                self.cmd_vel.publish(stop)

                while abs(diff) > 0.1:
                    rotation = Twist()
                    rotation.angular.z = 0.1 if diff > 0 else -0.1
                    self.cmd_vel.publish(rotation)
                    odometry = rospy.wait_for_message("/odom", Odometry)
                    diff = self.angle_difference(odometry)
                
                self.cmd_vel.publish(stop)
                go = Twist()
                go.linear.x = 0.05
                self.cmd_vel.publish(go)
                continue
            
            ## ELSE
            if self.mode == "test" or self.mode == "a":
                d = min(laser_scan.ranges[:180]) # return robot distance to wall
                err = d - self.D
            else:
                front_distance = min(laser_scan.ranges[:35])
                err = min([front_distance, min(laser_scan.ranges[35:180])]) - self.D   # return distance from side wall

            if err == float('inf'):
                err = 10
            else:    
                self.errs.append(err)
                
            sum_i_theta += err * self.dt
            
            P = self.k_p * err
            I = self.k_i * sum_i_theta
            D = self.k_d * (err - previous_error)

            move.angular.z = P + I + D 
            previous_error = err
            
            if self.mode == "test" or self.mode == "a":
                move.linear.x = self.v          
            else:
                if front_distance < self.D:
                    move.linear.x = 0
                else:
                    move.linear.x = self.v
                        
            self.r.sleep()
            

if __name__ == '__main__':
    try:
        pi = math.pi
        pidc = PIDController()
        pidc.follow_wall()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation terminated.")