#!/usr/bin/python3

import rospy
from nav_msgs.msg import Odometry
from distance_calculator.msg import Obstacle
import math

class ClosestObstacle:
    
    def __init__(self) -> None:
        rospy.init_node("minimum_distance_node" , anonymous=True)
        self.odom_subscriber = rospy.Subscriber("/odom" , Odometry , callback = self.calculate_distance)
        self.obstacle_publisher = rospy.Publisher('/ClosestObstacle' , Obstacle , queue_size=10)
        
        # obstacle details
        self.obstacles_dictionary = {
            "bookshelf" : (2.64, -1.55),
            "dumpster" :  (1.23, -4.57),
            "barrel" :    (-2.51, -3.08),
            "postbox" :   (-4.47, -0.57),
            "brick_box"	: (-3.44, 2.75),
            "cabinet" :	  (-0.45, 4.05),
            "cafe_table": (1.91, 3.37),
            "fountain" :  (4.08, 1.14)
        }
        
    def calculate_distance(self,odom):
        x_position = odom.pose.pose.position.x
        y_position = odom.pose.pose.position.y
        minimum_diststance = 10 ** 6
        for this_obstacle,position in self.obstacles_dictionary.items():    
            distance = math.sqrt(((x_position - position[0]) ** 2) + ((y_position - position[1]) ** 2))
            if distance < minimum_diststance:
                closest = this_obstacle
                minimum_diststance = distance
        obstacle = Obstacle()
        obstacle.obstacle_name = closest
        obstacle.distance = minimum_diststance
        rospy.loginfo(f"Closest Obstacle Published: {closest} Distance : {minimum_diststance}")
        self.obstacle_publisher.publish(obstacle)

if __name__ == "__main__":
    start_node = ClosestObstacle()
    rospy.spin()
