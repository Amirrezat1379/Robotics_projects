#!/usr/bin/python3

import rospy
from distance_calculator.msg import Obstacle
from distance_calculator.srv import GetDistance

class ClosestObstacle:
    
    def __init__(self) -> None:
        rospy.init_node("minimum_distance_node" , anonymous=True)
        # prepare service
        rospy.wait_for_service('get_distance')
        self.get_distance_service = rospy.ServiceProxy('get_distance', GetDistance)
        self.obstacle_publisher = rospy.Publisher('/ClosestObstacle' , Obstacle , queue_size=10)
        
        # obstacle details
        self.obstacles_dictionary = {
            "bookshelf" : (2.64, -1.55),
            "dumpster" :  (1.23, -4.57),
            "barrel" :    (-2.51, -3.08),
            "postbox" :   (-4.47, -0.57),
            "brick_box"	: (-3.44, 2.75),
            "cabinet" :	  (-0.45, 4.05),
            "cafe_table": (1.91, 3.37),
            "fountain" :  (4.08, 1.14)
        }
        
    def calculate_distance(self):
        while True :
            minimum_diststance = 10 ** 6
            for this_obstacle in self.obstacles_dictionary.keys():    
                res = self.get_distance_service(this_obstacle)
                current_distance = res.distance
                if current_distance < minimum_diststance:
                    closest = this_obstacle
                    minimum_diststance = current_distance
            obstacle = Obstacle()
            obstacle.obstacle_name = closest
            obstacle.distance = minimum_diststance

            rospy.loginfo(f"Closest Obstacle Published: {closest} Distance : {minimum_diststance}")
            self.obstacle_publisher.publish(obstacle)

if __name__ == "__main__":
    startNode = ClosestObstacle()
    startNode.calculate_distance()
